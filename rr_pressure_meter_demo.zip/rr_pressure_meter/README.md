# RR Pressure Meter — prototype

Place the original competition ZIP alongside `pressure_engine.py` as `data_pack.zip`, or pass its path explicitly.

```bash
pip install -r requirements.txt
python pressure_engine.py data_pack.zip outputs
streamlit run app.py
```

The app reads the generated rankings. Model is exploratory; read the engine's comments and validate before competition submission. Pressure is computed pre-delivery. Score uses contextual heuristics and percentile scaling among eligible players. Do not interpret ratings as calibrated probabilities.
