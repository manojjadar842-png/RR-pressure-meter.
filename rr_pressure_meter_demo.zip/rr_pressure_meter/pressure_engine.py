"""RR Pressure Meter — exploratory rankings, not official auction advice."""
import io, zipfile, sys
from pathlib import Path
import numpy as np
import pandas as pd

ZIP = Path(sys.argv[1]) if len(sys.argv)>1 else Path('data_pack.zip')
OUT = Path(sys.argv[2]) if len(sys.argv)>2 else Path('outputs')
OUT.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(ZIP) as z:
    def load(name):
        p=next(n for n in z.namelist() if n.endswith('/'+name+'.csv') and '__MACOSX' not in n)
        return pd.read_csv(io.BytesIO(z.read(p)))
    balls=load('ball_by_ball'); matches=load('matches'); comps=load('competitions')
balls=balls.merge(matches[['match_id','comp_id','revised_target','second_inn_revised_overs','first_inn_revised_overs']],on='match_id',validate='many_to_one')
balls=balls.merge(comps[['comp_id','comp_name','match_format','season']],on='comp_id',validate='many_to_one')
balls=balls[balls.innings.isin([1,2])].copy()
balls['is_ipl']=balls.comp_name.str.match(r'^IPL\s+20\d\d$',case=False)
balls=balls[balls.is_ipl | balls.match_format.eq('T20I')].copy()
balls['extra']=balls.extras1_runs.fillna(0)+balls.extras_2_runs.fillna(0)
balls['total_runs']=balls.runs.fillna(0)+balls.extra
balls['legal']=~balls.extras_type.fillna('').str.lower().isin(['wide','overstep'])
balls['bowler_runs']=balls.runs.fillna(0)+np.where(balls.extras_type.fillna('').str.lower().isin(['wide','overstep']),balls.extra,0)
balls['batter_ball']=balls.extras_type.fillna('').str.lower().ne('wide')
balls['batter_out']=balls.is_wicket.fillna(False) & balls.dismissed_player_id.eq(balls.striker_id) & ~balls.dismissal_type.fillna('').str.lower().isin(['retire out','retired out','obstructing the field','obstracting the field'])
balls['bowler_wicket']=balls.is_wicket.fillna(False) & ~balls.dismissal_type.fillna('').str.lower().isin(['runout','retire out','retired out','obstructing the field','obstracting the field'])
# Use source row order: innings_ball_num may include illegal deliveries.
balls['source_order']=np.arange(len(balls))
balls=balls.sort_values(['match_id','innings','source_order'])
g=balls.groupby(['match_id','innings'],sort=False)
balls['score_before']=g.total_runs.cumsum()-balls.total_runs
balls['wickets_before']=g.is_wicket.cumsum()-balls.is_wicket.astype(int)
balls['legal_before']=g.legal.cumsum()-balls.legal.astype(int)
balls['overs_limit']=np.where(balls.innings.eq(1),balls.first_inn_revised_overs,balls.second_inn_revised_overs)
balls['overs_limit']=pd.to_numeric(balls.overs_limit,errors='coerce').fillna(20).clip(lower=1,upper=20)
balls['remaining']=np.maximum(1,balls.overs_limit*6-balls.legal_before)
first_totals=balls[balls.innings.eq(1)].groupby('match_id').total_runs.sum()
balls['target']=balls.match_id.map(first_totals)+1
balls['target']=np.where(balls.revised_target.notna(),balls.revised_target,balls.target)
balls['needed']=np.maximum(0,balls.target-balls.score_before)
balls['rrr']=balls.needed/balls.remaining*6
balls['wickets_left']=10-balls.wickets_before
# Context score: transparent heuristic; chasing and defending have different contexts.
late=(1-balls.remaining/(balls.overs_limit*6)).clip(0,1)
scarcity=((6-balls.wickets_left)/6).clip(0,1)
chase=balls.innings.eq(2)
rate=(balls.rrr/15).clip(0,1)
close=(1-(balls.needed/np.maximum(1,balls.remaining*2))).clip(0,1)
balls['pressure']=np.where(chase,100*(.45*rate+.25*late+.15*scarcity+.15*close),100*(.50*late+.30*scarcity+.20*(balls.score_before/np.maximum(1,balls.legal_before+1)<1.1)))
balls['pressure']=balls.pressure.clip(0,100)
balls['high_pressure']=balls.pressure>=65
# Aggregate at match-player level, enabling consistency checks.
def summary(role):
    pid,pname=('striker_id','striker_name') if role=='batting' else ('bowler_id','bowler_name')
    d=balls.copy()
    d['balls']=d.batter_ball.astype(int) if role=='batting' else d.legal.astype(int)
    d['contribution']=d.runs if role=='batting' else d.bowler_runs
    d['wickets']=d.batter_out.astype(int) if role=='batting' else d.bowler_wicket.astype(int)
    d['dots']=((d.bowler_runs==0)&d.legal).astype(int) if role=='bowling' else (d.runs==0).astype(int)*d.batter_ball.astype(int)
    match=d.groupby([pid,pname,'match_id','high_pressure'],dropna=False).agg(balls=('balls','sum'),runs=('contribution','sum'),wickets=('wickets','sum'),dots=('dots','sum')).reset_index()
    full=match.groupby([pid,pname,'high_pressure'],dropna=False)[['balls','runs','wickets','dots']].sum().reset_index()
    wide=full.pivot(index=[pid,pname],columns='high_pressure',values=['balls','runs','wickets','dots']).fillna(0)
    wide.columns=[f'{v}_{"pressure" if pressure else "normal"}' for v,pressure in wide.columns]
    wide=wide.reset_index()
    for field in ['balls','runs','wickets','dots']:
        for part in ['pressure','normal']:
            col=f'{field}_{part}'
            if col not in wide: wide[col]=0
    p=wide.balls_pressure.clip(lower=1); n=wide.balls_normal.clip(lower=1)
    if role=='batting':
        wide['pressure_rate']=100*wide.runs_pressure/p
        wide['normal_rate']=100*wide.runs_normal/n
        wide['delta']=wide.pressure_rate-wide.normal_rate
        wide['base_metric']='strike rate'
        min_balls=60
    else:
        wide['pressure_rate']=6*wide.runs_pressure/p
        wide['normal_rate']=6*wide.runs_normal/n
        wide['delta']=wide.normal_rate-wide.pressure_rate
        wide['base_metric']='economy'
        min_balls=60
    # Shrink high-pressure rate differences toward zero for small samples.
    wide['shrunk_delta']=wide.delta*wide.balls_pressure/(wide.balls_pressure+100)
    wide['pressure_matches']=match[match.high_pressure & (match.balls>0)].groupby(pid).match_id.nunique().reindex(wide[pid]).fillna(0).to_numpy()
    wide['eligible']=(wide.balls_pressure>=min_balls)&(wide.balls_normal>=100)&(wide.pressure_matches>=5)
    if role=='batting':
        wide['raw_score']=wide.pressure_rate/10 +wide.shrunk_delta/12 -wide.wickets_pressure/p*50
    else:
        wide['raw_score']=18-wide.pressure_rate+wide.shrunk_delta +wide.wickets_pressure/p*70+wide.dots_pressure/p*5
    # Rank relative to eligible cohort, 0-100 percentile (not win probabilities).
    wide['rating']=np.nan
    eligible=wide.eligible
    wide.loc[eligible,'rating']=(wide.loc[eligible,'raw_score'].rank(pct=True)*100).round(1)
    wide=wide.sort_values(['eligible','rating','balls_pressure'],ascending=[False,False,False])
    wide.to_csv(OUT/f'{role}_rankings.csv',index=False)
    return wide
b=summary('batting'); w=summary('bowling')
print('Matches:',balls.match_id.nunique(),'Deliveries:',len(balls))
for name,df in [('BATTERS',b),('BOWLERS',w)]:
    print('\n',name)
    print(df[df.eligible].head(10).iloc[:,[1]].join(df[df.eligible].head(10)[['rating','balls_pressure','pressure_matches']]).to_string(index=False))
print('\nSaved outputs to',OUT.resolve())
