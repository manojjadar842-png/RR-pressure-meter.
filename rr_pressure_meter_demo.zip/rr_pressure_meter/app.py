import streamlit as st
import pandas as pd
from pathlib import Path
st.set_page_config(page_title='RR Pressure Meter',page_icon='🏏',layout='wide')
st.title('🏏 RR PRESSURE METER')
st.caption('Exploratory IPL + T20I scouting dashboard | Ratings are model-relative, not verified auction recommendations')
role=st.radio('Player role',['Batting','Bowling'],horizontal=True)
path=Path('outputs')/(role.lower()+'_rankings.csv')
if not path.exists():
 st.warning('Run pressure_engine.py with the data pack first to generate rankings.')
 st.stop()
df=pd.read_csv(path)
df=df[df.eligible==True].copy()
name='striker_name' if role=='Batting' else 'bowler_name'
season=st.slider('Minimum high-pressure balls',0,300,60,10)
df=df[df.balls_pressure>=season]
st.subheader('Top 10 eligible players')
cols=[name,'rating','balls_pressure','pressure_matches','pressure_rate','normal_rate','delta']
st.dataframe(df[cols].head(10),hide_index=True,use_container_width=True)
st.bar_chart(df.head(10).set_index(name)['rating'])
if not df.empty:
 player=st.selectbox('Inspect a player',df[name].tolist())
 p=df[df[name]==player].iloc[0]
 a,b,c=st.columns(3)
 a.metric('Pressure rating',f'{p.rating:.1f}/100')
 b.metric('High-pressure balls',int(p.balls_pressure))
 c.metric('Pressure matches',int(p.pressure_matches))
 st.write('Pressure vs normal',pd.DataFrame({'Metric':['High pressure','Normal'],'Value':[p.pressure_rate,p.normal_rate]}).set_index('Metric'))
 st.info('This is a first-pass heuristic model. Validate dismissal attribution, revised innings, context weighting and sample-size uncertainty before submitting rankings.')
